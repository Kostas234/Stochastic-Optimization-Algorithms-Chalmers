function derivative = PolynomialDifferentiation(vector, derivativeOrder)
 
  if derivativeOrder>length(vector)
    disp('The derivative order must be equal or smaller than the degree of the polynomial');
    return
  elseif derivativeOrder==length(vector) || vector == 0 || length(vector) == 0
    derivative = 0;
    return
  elseif derivativeOrder<=0
    disp("Error: Derivative order must be 1 or larger...");
    return
  end
  
  derivativeValue=0;
  for i = 1:derivativeOrder
    derivative = [];
    for j = 1:length(vector)-1
      derivativeValue = vector(j+1)*(j);
      derivative = [derivative derivativeValue];
    end
    vector = derivative;
  end

end
