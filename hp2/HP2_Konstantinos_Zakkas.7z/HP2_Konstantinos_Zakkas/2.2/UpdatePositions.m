function position = UpdatePositions(prevPosition, velocity)

  position = prevPosition + velocity;

end